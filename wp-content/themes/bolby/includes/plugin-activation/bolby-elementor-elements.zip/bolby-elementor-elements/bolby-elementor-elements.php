<?php 
/*
Plugin Name: Bolby Elementor Elements
Plugin URI: https://themeforest.net/user/pxlsolutions
Description: Bolby elements
Author: Pxltheme
Author URI: http://pxltheme.com
Version: 1.1
Text Domain: bolby
*/
include_once( 'loader.php' );