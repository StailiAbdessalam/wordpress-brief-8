<?php 
/*
Plugin Name: Bolby Custom Post Type
Plugin URI: https://themeforest.net/user/pxlsolutions
Description: Bolby Custom Post Type
Author: Pxltheme
Author URI: http://pxltheme.com
Version: 1.0
Text Domain: bolby
*/
include_once( 'loader.php' );